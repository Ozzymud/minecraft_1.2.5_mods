WorldGenEdit (Wedge) for Minecraft 1.2.5 version 0.3.0
                  by Ryan "UMM" Holtz

          TABLE OF CONTENTS
-------------------------------------

1.........................About Wedge
2....................How To Use Wedge
3.................Contact Information



             ABOUT WEDGE
-------------------------------------

WorldGenEdit, or Wedge, is a world generation toolkit for Minecraft. It allows
the user to create a custom world, editing nearly every parameter pertaining to
the default "Surface" terrain generator. Wedge also has a handy preview window
for previewing a few chunks of a given set of terrain settings without needing
to create an entirely new world, which is useful given the odd nature of many
of the given settings.

Wedge will eventually extend into tweaking BiomeGen settings as well, and in
time, the creation and modification of tree generators, cave generators, and
other features involved in Minecraft's auto-generated terrain.



          HOW TO USE WEDGE
-------------------------------------

Install the latest version of ModLoader, then install Wedge. It should have a
relatively small number of edited base classes, limiting itself to WorldType,
WorldProvider, and GuiCreateWorld, which are hopefully esoteric enough that
major utility such as Optifine don't collide.

Next, create a new world. There will be a button labelled "Create Wedge World".
Click that button to create a new world using the Wedge UI. If you're wondering
about what any of the options do, simply go to the "Tutorial" mode and generate
a visualization of the parameter in question!

In this creation mode, you are given complete control over all surface terrain
generation parameters, as well as ore counts and IDs. What you get out of
Wedge is entirely up to you: Use it to create fun new worlds with outlandish
natural structures, use it to learn more about Minecraft's terrain generation,
or use it to start creating your own terrain generators for your own mod!



        CONTACT INFORMATION
-------------------------------------

AIM: mega64man1
IRC: irc.esper.net, UltraMoogleMan
E-Mail: rholtz at batcountryentertainment beans dot com, hold the beans

- UMM, 5 Apr. 2012