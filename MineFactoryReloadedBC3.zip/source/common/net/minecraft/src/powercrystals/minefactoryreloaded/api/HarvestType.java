package net.minecraft.src.powercrystals.minefactoryreloaded.api;

public enum HarvestType
{
	Normal,
	LeaveBottom,
	Tree,
	TreeLeaf
}
