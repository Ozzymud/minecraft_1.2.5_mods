package net.minecraft.src.powercrystals.minefactoryreloaded.core;

public interface IRotateableTile
{
	public boolean canRotate();
	public void rotate();
}
