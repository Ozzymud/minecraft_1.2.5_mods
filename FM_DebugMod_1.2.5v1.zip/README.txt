FinalMinuet's DebugMod for Minecraft 1.2.5v1
--------------------------------------------
1. Back up your minecraft.jar file.
2. Make sure you've backed up your minecraft.jar file.
3. Unzip the mod file you downloaded into a folder you can easily find.
4. Open minecraft.jar with an archive program (like WinRAR, 7-zip, Archive Utility, etc).
5. Delete META-INF folder from minecraft.jar if you haven't already done so.
6. Copy all the files from the mod folder into minecraft.jar.

Important note for using the FM DebugMod with patching programs:
* Install this mod on an UNPATCHED minecraft.jar BEFORE you use your patcher!

FEATURES
* Pressing F3 will toggle minimal debug text mode. Just the world info.
* Pressing Shift+F3 will toggle full debug text mode. World info, memory usage, etc.
* Pressing F4 will toggle the frame rate and profiler graphs.
* Pressing F7 will cycle the graph's opacity between 100%, 75%, 50%, and 25%.
* Graphs are restricted to the lower left corner of the screen.
* Graphs will not continue to draw if you pause or exit to the main menu.
* Overall graph performance has been improved.
* Restored entity labels during debug mode with an optional file.
* Enhanced performance during minimal debug mode with an optional file.

Understanding the Mod Files
---------------------------
The FM DebugMod comes in three parts:
* DebugMod (using DebugGraph.class and /net/minecraft/client/Minecraft.class)
* Entity label patch (using fe.class)
* Minimal debug info patch (using aiy.class)

At the very least, you need to install the DebugMod files. The additional patches
are optional in the event that you have another mod that uses one or more of those
files, or if you just don't like the features of that patch.

IMPORTANT: You MUST install DebugGraph.class and Minecraft.class together if
you want to use the new debug graphs.

How Do the Graphs Work? What Do They Show?
------------------------------------------
Both graphs display information about how long it takes the game to run. There
are two times measured: the frame time, which is the time spent on a single
iteration through the game loop; and tick time, which is the time spent on a
single game tick (a loop that processes input and updates the game world).
Basically, the times are inversely proportional to your FPS; that is, the less
time it takes to render a game tick, the higher your FPS. This explanation side-
steps a lot of details, but at least you get the gist of it.

The graph on the left displays the average frame time, updated constantly. When
the average frame time is faster than the ideal frame time (set by Mojang, not
me), the graph will be completely green with a dark backing above to show how
much faster. If the average frame time is slower than the ideal, the top part
of the graph will be red. The red portion gets brighter as it grows upward, and
stops halfway up the screen to prevent it from blocking the rest of the screen.

The graph on the right plots the current frame and tick times. The bottom part
works the same as the other graph. When the line is green your frame time is
faster than the ideal, and when the line is red it's slower. The top part is the
tick time and does not change color with performance.

In short, green is good and red is bad.

DISCLAIMER: I make no warranty about compatibility with other mods. Use this
mod at your own risk. I take no responsibility for damages incurred while using
this mod. I am not affiliated with Minecraft, Mojang, or any other entities. All
trademarks are owned by their respective companies. This mod is only to be used
on legally owned copies of Minecraft. By downloading this mod, you agree to only
use this mod for personal use. Unauthorized redistribution is strictly
prohibited. Original works copyright (C) 2011-2012 FinalMinuet.

