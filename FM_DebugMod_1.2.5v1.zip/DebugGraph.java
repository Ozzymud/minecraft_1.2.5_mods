package net.minecraft.src;

import org.lwjgl.opengl.GL11;
import org.lwjgl.LWJGLException;

public final class DebugGraph {
	/**
	 * Private constructor to enforce Singleton pattern. Initializes values
	 * to defaults.
	 */
    private DebugGraph() {
    	arraySize = 200;
    	frameTimes = new long[arraySize];
    	tickTimes = new long[arraySize];
    	frameTimeAverage = 0L;
    	frameTimeSum = 0L;
    	recordedFrames = 0;
    	prevSystemTime = -1L;
    	
    	frameScale = 0x30D40L;
    	optimumFrameTime = 0xFE502AL;
    	OTS = (int)(optimumFrameTime / frameScale);
    	
    	debugOpacity = 1.0D;
    	opacityStep = 0.25D;
    	alpha = 255;
    	
    	minx = 0.0D;
    	maxx = (double)arraySize;
    	miny = 0.0D;
    	maxy = 0.0D;
    	gapx = 40.0D;
    	
    	fade = 200;
    	fadeFactor = 256.0D / (double)(fade * fade);
    }
    
    /**
     * Checks if the graph has been instantiated and is ready to draw.
     *
     * @return true if graph is instantiated, false otherwise
     */
    public static boolean isDrawing() {
    	return (graph != null);
    }
    
    /**
     * Toggles the status of graph drawing. If the graph is not instantiated,
     * calls the private constructor and enables graph drawing.
     *
     * @return true if graph was not instantiated, false otherwise
     */
    public static boolean toggleOperation() {
    	if (graph == null) {
    		graph = new DebugGraph();
    		return true;
    	}
    	else {
    		DebugGraph.destroy();
    		return false;
    	}
    }
    
    /**
	 * Decrements the opacity of the graph by the default amount. If the new
	 * value would be <= 0.0, then the opacity is looped back to 1.0. Also
	 * sets the RGBA alpha value.
	 *
	 * @return the new opacity value, or 0.0 if graph is not instantiated
	 */
	public static double stepOpacity() {
		if (graph != null) {
			graph.debugOpacity = (graph.opacityStep < graph.debugOpacity)
				? graph.debugOpacity - graph.opacityStep : 1.0D;
			graph.alpha = (int)(255 * graph.debugOpacity);
			
			return graph.debugOpacity;
		}
		
		return 0.0D;
	}
	
	/**
	 * Public interface to drawing method. Calls the graph.draw() method
	 * directly to make the coding shorter and more readable.
	 *
	 * @param lastGameTick the time spent on the last game tick, in nanoseconds
	 * @param dWidth the width of the drawing surface
	 * @param dHeight the height of the drawing surface
	 */
	public static void draw(long lastGameTick, int dWidth, int dHeight) {
		if (graph != null) {
			graph.drawGraphs(lastGameTick, dWidth, dHeight);
		}
	}
	
	/**
	 * Stores the latest recorded tick time, updates the time arrays, and
	 * draws the graphs using the specified parameters.
	 *
	 * @param lastGameTick the time spent on the last game tick, in nanoseconds
	 * @param dWidth the width of the drawing surface
	 * @param dHeight the height of the drawing surface
	 */	
	private void drawGraphs(long lastGameTick, int dWidth, int dHeight) {
		// Sets up OpenGL drawing surfaces. Don't mess with this.
        GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0D, dWidth, dHeight, 0.0D, 1000D, 3000D);
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0F, 0.0F, -2000F);
        GL11.glLineWidth(1.0F);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_BLEND);
        
        // Sets the drawing bounds
        maxy = dHeight;
        miny = dHeight / 2;
        
        // Adds lastGameTick to stored values and updates array.
        int index = recordedFrames++ % arraySize;
        long lastTime = (recordedFrames < arraySize) ? 0L : frameTimes[index];
        tickTimes[index] = lastGameTick;
        
        // Calculates the frame time.
        long currentSystemTime = System.nanoTime();
        frameTimes[index] = currentSystemTime - prevSystemTime;
        if (prevSystemTime < 0L) {
        	frameTimes[index] = optimumFrameTime;
        }
		prevSystemTime = currentSystemTime;
        
        // Calculates the running frame time average.
        int div = (recordedFrames < arraySize) ? recordedFrames : arraySize;
        frameTimeSum = frameTimeSum - lastTime + frameTimes[index];
        frameTimeAverage = (long)(((frameTimeSum / frameScale) / div) / 2);
        
        // Set the top vertical point for drawing the FPS graph
        double topdist = maxy - frameTimeAverage;
        double top = (topdist < miny) ? miny : topdist;
        
        // Draws graph for average FPS
        t.startDrawing(GL11.GL_QUADS);
        t.setColorRGBA(0, 160, 0, alpha);
        t.addVertex(minx, top, 0.0D);
        t.addVertex(minx, maxy, 0.0D);
        t.addVertex(minx + gapx, maxy, 0.0D);
        t.addVertex(minx + gapx, top, 0.0D);
        if (frameTimeAverage > OTS)
        {
	        double clr = 128.0F / (miny - 1);
	        clr = 128 + ((maxy - OTS - top) * clr);
	        t.setColorRGBA((int)clr, 0, 0, alpha);
	        t.addVertex(minx, top, 0.0D);
	        t.addVertex(minx, maxy - OTS + 1, 0.0D);
	        t.addVertex(minx + gapx, maxy - OTS + 1, 0.0D);
	        t.addVertex(minx + gapx, top, 0.0D);
        }
        else
        {
	        t.setColorRGBA(32, 32, 32, alpha);
	        t.addVertex(minx, maxy - OTS, 0.0D);
	        t.addVertex(minx, top, 0.0D);
	        t.addVertex(minx + gapx, top, 0.0D);
	        t.addVertex(minx + gapx, maxy - OTS, 0.0D);
        }
        t.draw();
        
        // Draws graphs for frame/tick times
        t.startDrawing(GL11.GL_LINES);
        double curx = gapx;
        double scaledFrame, scaledTick;
        int intensity;
        
        for(int c = 0; c < arraySize; c++) {
            if (c >= recordedFrames) {
                break;
            }
            
            scaledFrame = (frameTimes[c] / frameScale > miny)
            	? miny : frameTimes[c] / frameScale;
            scaledTick = (tickTimes[c] / frameScale > miny)
            	? miny : tickTimes[c] / frameScale;
            
            int z = index - c;
            if ((z >= 0) && (z < fade)) {
                intensity = (int)(256 - (z * z * fadeFactor));
            }
            else if ((index < fade) && ((z + arraySize) < fade)) {
                z += arraySize;
                intensity = (int)(256 - (z * z * fadeFactor));
            }
            else {
                intensity = 0;
            }
            
            double b = maxy - scaledFrame;
            if (frameTimes[c] > optimumFrameTime) {
                t.setColorRGBA(intensity, 0, 0, alpha);
            }
            else {
                t.setColorRGBA(0, intensity, 0, alpha);
            }
            t.addVertex(curx, b, 0.0D);
            t.addVertex(curx, maxy, 0.0D);
            t.setColorRGBA(intensity, intensity, intensity, alpha);
            t.addVertex(curx, b, 0.0D);
            t.addVertex(curx, b + scaledTick, 0.0D);
            curx++;
        }
        t.draw();
        
        // Reset drawing states
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
    }
	
	
	/**
     * Cleans up any used memory and uninstantiates the graph object.
     */
	private static void destroy() {
		if (graph != null) {
			graph.frameTimes = null;
			graph.tickTimes = null;
			graph = null;
		}
	}
	
	/**
     * Number of frame and tick times to record in active memory.
     */
    private int arraySize;
    
    /**
     * Array of frame times in nanoseconds. A single frame is a complete loop
     * through the game code, starting and ending in the draw() method.
     */
    private long frameTimes[];
    
    /**
     * Array of tick times in nanoseconds. A single tick is basically the time
     * spent running the Minecraft.runTick() method.
     */
    private long tickTimes[];
    
    /**
     * Keeps a running average of all recorded frame times, used in finding
     * the average FPS.
     */
    private long frameTimeAverage;
    
    /**
     * Keeps a running sum of all recorded frame times, to reduce time spent
     * on calculating the average.
     */
    private long frameTimeSum;
    
    /**
     * Counts the total number of frames recorded and drawn.
     */
    private int recordedFrames;
    
    /**
     * Records the last system time accessed, in nanoseconds.
     */
	private long prevSystemTime;
	
	/**
     * Magic number created by Notch. Used in scaling down the frame times
     * to a drawable height.
     */
    private long frameScale;
    
    /**
     * Magic number created by Notch. Equal to the number of nanoseconds each
     * frame would have to run in order to achieve 60 FPS.
     */
    private long optimumFrameTime;
    
    /**
     * Ratio between optimumFrameTime and frameScale. Used in scaling down the
     * frame times to a drawable height. OTS = optimum time scale
     */
    private int OTS;
    
    /**
     * Percentage of opacity used when drawing graphs. Between 0.0 and 1.0.
     */
    private double debugOpacity;
    
    /**
     * Percentage of opacity to decrement by. Between 0.0 and 1.0.
     */
    private double opacityStep;
    
    /**
     * The RGBA alpha value, calculated from debugOpacity. Between 0 and 255.
     */
    private int alpha;
    
    /**
     * Drawing bound on graph: minimum x-coordinate.
     */
    private double minx;
    
    /**
     * Drawing bound on graph: maximum x-coordinate.
     */
    private double maxx;
    
    /**
     * Drawing bound on graph: minimum y-coordinate.
     */
    private double miny;
    
    /**
     * Drawing bound on graph: maximum y-coordinate.
     */
    private double maxy;
    
    /**
     * Drawing bound on graph: width of average FPS graph.
     */
    private double gapx;
    
    /**
     * Length of fading trail behind current drawing point.
     */
    private int fade;
    
    /**
     * Amount to decrement color values by, based on fade length.
     */
    private double fadeFactor;
    
    /**
     * Singleton instance of Tessellator.
     */
    private static Tessellator t = Tessellator.instance;
    
    /**
	 * Private declaration of the Singleton instance. Initially set to null,
	 * but will be instantiated upon request to save memory.
	 */
	private static DebugGraph graph = null;
}

