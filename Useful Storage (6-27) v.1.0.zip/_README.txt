To install:
	Simply drag everything from this folder into your .jar.
	(Make sure you delete META-INF and have Forge installed!)
	
	Both of the two editted base-classes are completely optional:
	- If you do not install 'bc.class', Animals will no longer run from Scarecows in fear
	- If you do install 'xa.class', you will remove the ability to craft Scarecows in game

The version is v.1.0. This mod will only work with Minecraft [1.2.5].

Known issues:
	Edits the base bc.class (EntityAnimal)
		currently only done so that Animals run away from crafed Scarecows - will likely add more to this in the future
	Edits the base xa.class (BlockPumpkin)
		as far as I am aware, this is necessary in order to be able to craft a new "golem" creature

Changelog:
	v.1.0 (6/27)
		- release

Please leave feedback/any other questions you may have on the official topic.
Otherwise, I hope you enjoy! :D

- Ian