Minecraft Control Pack v5.0 - for Minecraft 1.2.5

04/12/2012
by InfinitiesLoop
minecraftcontrolpack@infinity88.com
==============================
This is a Minecraft client mod that requires nothing from the server. That means you can use it for
SMP _and_ Single Player!

Feature Listing (explainations below)
=====================================
Auto Tool Selection
Auto Sword Selection
Auto Block Selection
Stack Preservation
Place Torch
Eat Food
Tap to Sprint
Disable Void Fog
Automatic Window Restoration
Better 3rd Person View
Auto Run
Toggle Sneak
Toggle Jump
Swap Left
Swap Right
Toggle Mining
Toggle Use Item
Run Distance
Look Behind
Smart Furnace Drops
Render Less Rain
Toggle Full Brightness
SFX Volume Control
Coordinates Overlay
Waypoints
Say your location


CONFIGURING THE OPTIONS
===========================
You can configure all the key binding and turn features on/off via the Control Pack
setting screen. You can get to the screen via the regular Minecraft Setting screen,
or you can hit [ALT+C] while in the game.


ALL ABOUT THE FEATURES
======================================================

Auto Tool Selection
===================
You'll wonder how you ever played Minecraft before this. With Auto Tool, just left click a block.
ControlPack will automatically select the best tool for the job from your toolbar! If the item
you are mining does not require a tool (like a torch), it will switch to your hand (or to a
regular item if you don't have any open slots).

You can customize how the tool selection works by putting it into one of these modes, right from
the included UI:

[Weakest Tool] (this is default value)
Select the weakest tool you have that will do the job. For example, if you have a wood pick and
a stone pick, it will normally select the wood pick while mining stone. If you find Iron Ore,
which requires at least a Stone pick, it will use the stone pick.

[Strongest Tool]
Always pick the fastest tool for the job, even if you have lesser tools that would work.

[Leftmost]
No magic, just pick the first tool on the toolbar that is appropriate for the block.

[Rightmost]
No magic, just pick the last tool on the toolbar that is appropriate for the block.

Of course, there may be times you want to use a particular tool. You can very easily turn auto tool
on and off by hitting ALT+T.

You can also quickly cycle through the possible modes using ALT+R.

Note that this works even while using the toggle-mining feature. That means you can turn on
toggle mining, and sit back as you automatically switch between picks and shovels as you run into
dirt or gravel patches.


Auto Sword Selection
====================
Left click a mob, and it'll select your sword automatically! Don't have one? It will also make sure
you don't have a tool selected so you don't waste a use.

You can quickly enable and disable Auto Sword with ALT+S.

If you have a mod that provides weapons other than a sword you want to auto select, you can customize
which items ControlPack thinks are swords in the options screen. Just provide a comma-delimited list
of the item IDs.


Auto Block Selection
====================
What happens if you right click while holding a tool, like a pick axe? Nothing! Until now.
Auto Block is like the opposite of Auto Tool. When you right click while holding a tool, ControlPack
automatically switches to a placeable block or item in your toolbar, and places it!

You can customize how it decides which block to place by putting it into one of these mods, right
from the included UI:

[Leftmost] (the default)
Uses the first placeable block or item that is on your toolbar.

[Rightmost]
Uses the last placable block or item that is on your toolbar.

[Slot #]
You can set it to a specific slot number (1 through 9). Then it will place whatever block is in that
slot, if any.

You can quickly enable and disable Auto Block with ALT+B.

Remember it applies to any placeable item or block, even torches. So picture this: In the first 3
slots of your inventory you have a pick, a shovel, and torches. You mine away, and Auto Tool is 
switching between the pick and shovel for you. Now and then, you want to place a torch. All you do
is right click, and BAM, a torch is placed, then you just continue left-click mining! Can it get
ANY easier? Well, there's also the 'Place Torch' key :)

With Control Pack, you'll almost never have to worry about switching between inventory items!


Stack Preservation
==================
If you place the last item in a stack, and you have another stack on your toolbar, it will automatically
switch to that item, so you can continue placing the block or item without having to switch to the new
slot! This feature is enabled/disabled along with Auto Block.


Place Torch
===========
Now you have a keyboard or mouse key that will always place a torch as long as you have one on your
toolbar. And it switches back to what you had before right away.

If you don't have any torches, it will also place a Redstone Torch.


Eat Food
========
Hungry? Just press and hold the 'Eat Food' button. You'll automatically start eating whatever the
first food item is on your toolbar. Release the button and you'll stop eating and automatically
swap back to the previous item you were holding.


Tap to Sprint
=============
Notch added sprinting, which is nice and all, but it's rather clumsy having to double tap the forward
button to do it. ControlPack adds a key you can tap (default is F) while holding forward to begin
sprinting. Ahhh, much easier.


Disable Void Fog
================
When you are near the bottom of the map, Minecraft get's really aggressive with the fog. You can't see
more than 10-15 blocks in front of you! Even with plenty of torches, it's total blackness. Many servers
have complained about this feature, because it ruins your creations if you happened to have built near
the bottom of the map. Thankfully, turning it off is just a click away. 

It is ON by default, so be sure and hit ALT+C to see the options and turn it off.


Automatic Window Restoration
============================
ControlPack remembers the size and position of your Minecraft window and automatically restores it
when the game launches (after you log into minecraft.net in the launcher). It will not only remember
the size and position, but also the fullscreen status of the window.


Better 3rd Person View
============================
Minecraft has three camera modes. The normal view, and two 3rd person views. The two 3rd person views
let you view your character from the front or the back. But, the problem with these views is that you
are ALWAYS either directly in front of or behind your head, and movement of the camera is locked to
the movement of your head.

ControlPack adds another 3rd person view that separates camera control from head movement. This allows
you, for example, to view your character from the side, from above, or from below. You can see yourself
turn 360 degrees around as the camera stays in the same position.

You can rotate the camera up/down and left/right by holding down the middle mouse button and moving the
camera freely. You can also do it with the keyboard by holding down CONTROL and then using your usual
directional keys. For example, CTRL+LEFT will rotate the camera to the left.

Just keep tapping F5 to toggle through all the views as usual.


Swap Left and Swap Right
========================
These are 'press and hold' commands meant to let you use a tool _temporarily_.

Say you're mining away at some stone with a pick looking for resources, and you inevitably
run into a large patch of dirt or gravel. Normally, you have to switch to your shovel. With
the 'swap' commands, you simply hold down the swap key, get rid of the dirt or gravel, and then
release to automatically swap back to your pick. 

Also great while building. Perhaps you are working on a building that needs mostly stone but
with some glass every now and then. Well, swap to the glass temporarily when you need it. Easy!

Another great use -- if you're mob hunting, keep some pork or whatever to the left and right
of your sword. Healing up in mid-battle is much easier!


Toggle Sneak
============
Building something at high altitudes? Holding down shift when you're doing dangerous work can
be tiring and error-prone. Now you can toggle sneak and rest assured you won't fall down.

Also -- did you know that sneaking while on a ladder will let you stick to the ladder? Holding
down sneak to do that is great, but you can't do anything else without falling down.
You can't chat, get up to go to the bathroom, or eat Cheez-Its(r)! Toggle sneak and you're
good to go.


LOL Why Auto Jump?
===================
For swimming, of course! Now you can actually chat without drowning! Also great if you use it
in combination with Auto-Run so you can skip over small hills automatically, or swim across
an ocean.


Why Auto Run?
===============
For long distances, it makes things easier. Yes, you will have to jump
a lot along the way, but hey, there's auto JUMP too! And if you combine
this with Auto Jump while in the water, well, now you can swim across the
ocean and chat while you're doing it, or eat some Cheez-Its(r).


Toggle Mining
===============
Holding down the mouse button for long mining sessions can get tiring. Auto-mine to the rescue!
Just tap it, and you'll be swinging like there's no tomorrow (What if there is no tomorrow? There
wasn't one today!)

If you're especially lazy, also turn on auto-run, look just a tad bit down from the center,
and you'll not only auto-mine, you'll blaze a path while doing it! Afraid you might fall into a cavern?
No problem, turn on toggle sneak too!


Toggle Use Item
================
This is your right-click toggle. If you are building a lot, this might come in handy.
Note that autoblock's "exhasted" feature will still kick in here. So if you're auto placing a
block and your current stack runs out, it will automatically switch to a fresh stack if you have one
and continue placing them.


Run Distance
================
Stop staring at the ground counting blocks or using F3! Just enter how many blocks you want to go,
and you're off. It automatically stops after you've traveled that many blocks in any direction.
Don't worry about things in your way, walk around them, jump over them, or whatever you
have to do, it will still stop on the right spot, even if you have to back track.


Smart Furnace Drops
=====================
You'll wonder how you ever lived without this time-saver. When in the furnace UI, you can shift-click
items in your inventory to add them automatically to the furnace. Shift-click the items in the furnace
and they'll return to your inventory. But there's more to it than that.

ControlPack will figure out the best thing to do with the item:
x If it is a smeltable item, it puts it in the furnace queue or adds it to the existing queue.
x If it is a furnace fuel (coal, etc), it puts it in the fuel slot, or adds it to the existing fuel.
x When placing fuel, it knows how much is necessary to smelt all the items and only adds that many.
x When placing fuel, if there is already some fuel, it adds only enough to it to be able to smelt all the items.
x You can do all of this while already holding a completely different item.

What does this mean exactly? Say you have an empty furnace, 64 sand, and 64 coal. Normally, to smelt them
you would have to perform a ton of mouse operations, dragging things around, right clicking a bunch of times,
etc etc. It's kind of a pain.

Here's how you do it with ControlPack!
1. Shift-click the sand.
2. Shift-click the coal.
3. When it's done smelting, shift-click the glass. DONE!


Look Behind
=====================
You're down to 1 heart, and a Creeper starts charging you! What do you do? RUN!!!
How do you know if the creeper is still following you? Stop and turn around? But
then you risk him catching up with you!

Look behind makes your middle-mouse button to do something incredibly useful.
It causes your character to turn their head 180 degrees to look behind you, while
you are still running! Just hold it down to look behind you, then release to look
forward again. 

Don't have a middle mouse button? You can reconfigure it to any mouse or keyboard key.
You can also hold down the BACK button (that is, whatever key you have mapped to be your
'move backwards' button) while holding down the forward button -- thereby pressing forward
and back at the same time.


Render Less Rain
=================
I was happy when Notch added weather to Minecraft. And then it rained. "Rain" doesn't
really describe the weather in Minecraft. It's more like monsoon. And it gets rather
annoying really quick. It rains more than it does in Seattle.

With Less Rain when it rains you'll notice there's a lot less of it. About half as much,
actually. It will still rain as often, it just renders less rain drops.


Toggle Full Brightness
======================
When you use this command, your Minecraft brightness setting is set to MAX. Use the command
again to automatically restore the brightness to your previous value. This is a great way
of keeping the nice Moody brightness setting that Minecraft looks great in, but then easily
turning it up when you're in a dark cave, so you can see without even having any torches.
You get the best of both worlds!


Sound Effect Volume
====================
Rain is awfully loud in Minecraft. So are pistons. And everytime you splash into some water,
that splashing sound can be kind of jarring. Now you can control the volume of these 
sound effects, and more, independently of your main volume! You might enjoy hearing the
subtle sound of rain. You can even make sounds LOUDER* than normal if you want to.
Make explosions LOUDER!

* Some sounds won't get louder than they would be when your Minecraft sound setting is set to
  100%. To get them louder than other sounds, lower your Minecraft volume setting but increase
  your system volume to compensate.


Coordinates Overlay
===================
You can display your X, Y and Z coordinates constantly so you always have an idea of where you
are. Consider it a very lightweight and simple minimap. You can decided which corner of the
screen to show them in: top left, top right, bottom left, or bottom right. Or you can turn them
off, of course.

Note that the coordinates display in X, Z, and Y order. Y is your vertical position.


Waypoints
============
You can save up to 10 waypoints -- 5 in the Nether and 5 in the normal world. Each waypoint can
optionally be displayed on your HUD, and it will show the coordinates along with an arrow that
will always point in its direction. You can also provide each waypoint a name if you want. It's
a dead simple way of keeping track of your favorite spots.

Say your location
=================
Ever want to tell someone what your coordinates are, but it's almost impossible to chat and look
at the F3 screen at the same time? Forget that. Just type the Say Your Locatin key (INSERT by
default) while chatting, and your position will be inserted automatically for you as X, Z, Y 
coordinates.



Compatibility with other Mods
=============================
!!!!! MATMOS AND AUDIOMOD !!!!!
ControlPack is compatible with both of these mods, but NOT BOTH OF THEM AT THE SAME TIME!
You must pick one or the other! 

        If you want MATMOS COMPATIBILITY
                *DO* install sd.class

	If you want AUDIOMOD COMPATIBILITY
                *DO NOT* install sd.class.
                Everything will still work, except for Matmos.

        If you don't care which mod works
                *DO* install sd.class

AN UPDATE ABOUT MATMOS:
	Matmos has a new version that might change the compatibility behavior and I am not
	sure if the problem still exists. If you try it, please let me know by replying to
        the minecraft forum post.


!!!!! OPTIFINE !!!!!
The lr.class conficts. You will have to leave this file off and lose the associated features.
See below for the features you will lose. If you don't do this, Optifine will not behave
correctly, and you will find rendering problems like water not rendering.


!!!!! IMPROVED CHAT !!!!!
afu.class conflicts with Improved Chat. You MUST install the Control Pack version of this file.
It contains special code to make sure Improved Chat works even though you will be overwriting its
version of the file. The simpliest way to ensure you do it right is to install or reinstall
Control Pack AFTER installing Improved Chat.


!!!!! FORGE !!!!!
lr.class conflicts with Forge. You MUST install the Control Pack version of this file.
It contains special code to make sure Forge works even though you will be overwriting its
version of the file. The simpliest way to ensure you do it right is to install or reinstall
ControlPack AFTER installing Forge.
Note that while this has been tested to work with Forge itself, this does NOT automatically mean
that Control Pack is compatible with all Forge mods.

Other mods:

If another mod also requires changes to minecraft.jar, there is a conflict if it needs to modify
any of the same class files that ControlPack modifies. ControlPack has been written so that 
you can leave off any conflicting class files and the mod will still work, but you'll lose the 
corresponding feature. Here is a list of the files ControlPack modifies and what they are used for.


cd.class
    OPTIONAL!
    Known Conflict: GUIAPI
    This just adds the ControlPack button to the options GUI. You can use ALT+C to open it instead.

lr.class
    OPTIONAL!
    Known Conflict: Optifine
    This enables look behind, better 3rd person view, less rain, and void fog removal.
    Note that a lesser version of Look Behind will still work without this file.

kv.class
    OPTIONAL!
    Enables Smart Furnace functionality.

sd.class
    OPTIONAL!
    Makes the sound effect volume feature compatible with the Matmos mod.
    You do NOT need this class if you don't need Matmos compatibility.

afu.class
    REQUIRED!!
    General plumbing for ControlPack.
    IF YOU OVERWRITE THIS FILE WITH ANOTHER MOD THAT CONTAINS IT, MINECRAFT WILL CRASH



INSTALLATION
=============
*** ALWAYS BACK UP YOUR MINECRAFT.JAR FILE ***

This involves replacing some files within the minecraft.jar file.
Always backup the file before you begin.

NOTE: If you are using other mods as well, read the compatibility section above to check if
any of your other mods require special installation instructions.

1. INSTALL MOD LOADER
	It doesn't matter if you do this before or after installing this mod.
	Refer to ModLoader instructions on installation, then come back here.
	If you already have ModLoader installed, you should be fine.
	You should use the latest version of ModLoader for the Minecraft version you
	are using. Get it here:
	http://www.minecraftforum.net/topic/75440-v166-risugamis-mods-updates/

STOP! After installing ModLoader, you should run Minecraft to make sure it works. If you did
      something wrong you will get a black screen at this point. Refresh your minecraft install
      and START OVER.

2. Locate the minecraft.jar file
	a. Start->Run->%appdata% <enter>
		This brings you to your windows profile "app data" folder, where programs store information.
	b. Go to the ".minecraft" folder, then the "bin" folder. BEHOLD!... minecraft.jar
		If these folders are missing or there's no minecraft.jar file, you probably haven't
		launched minecraft on the machine yet. Do that.

3. Open the minecraft.jar file. Best way to do this is to use a program called WinRAR.
	a. If you don't have WinRAR, Google it and install it. It's free.

4. If there is a META-INF folder within the minecraft.jar, you probably didn't install ModLoader correctly!
   You should start over with a fresh minecraft.jar, which you can get by restoring your backup. If you didn't
   make a backup, you can use the 'force update' option in Minecraft, found under the "Options" button on the
   main login/launcher screen. This will redownload the jar file so you can start over.

5. Copy the entire contents of the 'Classes' folder in the ControlPack zip file into the jar by dragging
   them into it.

 ** DO NOT COPY THE CLASSES FOLDER ITSELF, ONLY THE FILES CONTAINED WITHIN IT! **
 ** DO NOT COPY THE CLASSES FOLDER ITSELF, ONLY THE FILES CONTAINED WITHIN IT! **

	a. When dropping the files be sure it isn't dropping them into a folder in the jar file.
	b. If WinRAR (or whatever you used) prompts to confirm, make sure it is set to overwrite the
           existing files, and make sure you click 'ok', 'yes', 'confirm', or what have you.
	c. Close WinRAR

Done!

If Minecraft just gets a 'black screen' after logging in, you probably did something wrong :) Or there's a problem
with the version of Minecraft and the version of ModLoader and this mod because ModLoader and/or Minecraft have
updated their version after the version of this mod you attempted to install. Make sure you have the latest of
everything.

Before contacting me about the black screen, be sure and check this first. Start with a fresh unmodified
minecraft.jar file, then install ModLoader per ModLoader's instructions. Then before doing anything else,
launch Minecraft. It should work with just ModLoader installed and nothing else. If not, sorry, you missed
something.



CHANGE LOG
================
NEW IN VERSION 5.0
==================
x Minecraft 1.2.5 compatibility (well, 4.9 was already compatible, actually).
x You can now right click on keybindings to disable them.
x Added an Eat Food keybinding.
x You can now customize Auto Sword to select other items by providing a list of Item IDs.


================
NEW IN VERSION 4.9
==================
x Minecraft 1.2.4 compatibility.

================
NEW IN VERSION 4.8
==================
x Minecraft 1.2.3 compatibility.

================
NEW IN VERSION 4.7
==================
x Minecraft 1.1 compatibility.


NEW IN VERSION 4.6
==================
x Waypoints are now separate in the overworld and the nether, so you can have a different set of waypoints in each.
x AutoTool will now select a sword for webs if you don't have shears.
x ImprovedChat compatibility (READ THE COMPAT SECTION)
x Forge compatibility (READ THE COMPAT SECTION)

NEW IN VERSION 4.5
==================
x Greatly enhanced waypoints.
   a. You can now set up to 5 waypoints.
   b. You can optionally give each waypoint a name, and toggle whether to show them in the HUD.
   c. An arrow will render next to each HUD waypoint, indicating which direction it is in.
x The key for "say your location" is now a keybinding, and the default was changed to INSERT instead of GRAVE.
x Fixed a few bugs


NEW IN VERSION 4.4
==================
x Added an optional status overlay that shows you your toggle sneak, run, etc status.
x Added an optional coordinates overlay that shows you your current x, z, and y position.
x Added a "set waypoint" keybinding
x Say where you are! Type the back tick "`" key while chatting to automatically insert your coordinates.
x Added Eat & Drink to volume control options


NEW IN VERSION 4.3
==================
x Minecraft 1.0.0 compatible.

NEW IN VERSION 4.2
==================
x Matmos compatible.
x Still AudioMod compatible but with special instructions, see conflict section.
x Look Behind will now "sort of" work even if you don't include ControlPack's iw.class.
  This class conflicts with Optifine and Forge. Previously this meant you had to lose look behind altogether.
  Now in this situation, it will work, but a slightly less fun way. You won't see the 'tilting' effect,
  the tool in your hand will still render, and your vertical tilt won't flip (e.g. if you are looking straight
  up or straight own, look behind won't seem to do anything. Normally it flips the vertical view too).
x Auto Tool has been greatly enhanced:
	x Auto Sword is now a separate option that you can toggle on/off separately.
        x Switching tools now occurs BEFORE the first swing. This mattered especially with auto sword since
          if you swung at a mob with a tool, you hit it, and then switched to your sword, which causes a -2
          use on your tool.
        x Auto Tool will now swap to your hand (or a lame item if you have no empty slots) if the block you
          are hitting does not require a tool to harvest, or if you don't have an appropriate tool for it.
          For example, swinging at a flower will pick it with your hand. Swinging at wood if you have no
          axe will hit it with your hand, etc.
        x Shears work! Previously this was not considered a tool. Now it will swap to shears if you swing at
          webs, cloth, leaves, or vines.
        x You can now change the strategy. Previously it always picked the strongest tool. Now you can set it
          to one of these modes:
                x Weakest (default): The weakest, yet appropriate tool is use. For example, if you have a
                  stone pick and an iron pick, it will normally use the stone pick. If you try to mine something
                  that requires the iron pick, like diamond ore, it will use that.
                x Strongest: Always uses the strongest an most appropriate tool you have available.
                x Leftmost: Uses the first appropriate tool on your toolbar, whatever it is.
                  For example, if your second-to-last slot is a shovel and the last slot is a pick,
                  it will use the shovel on dirt, and the pick on stone.
                x Rightmost: Uses the last approprite tool on your toolbar, whatever it is.
x Auto Block has been greatly enhanced:
        x You can now change the strategy. Previously it always picked the first placeable block in your toolbar.
          Now you can set it to use one of these modes:
                x Leftmost: Places the first placeable block that is on your toolbar.
                x Rightmost: Places the last placeable block that is on your toolbar.
                x Slot #1..#9: Places the block that is in that particular slot of your toolbar (if there is one).
        x When you place the last item in a stack, and you have more of that item in your toolbar,
          it will automatically switch your current item to that item.
        x The above rule works even while using Toggle Use Item.
x Added volume control for: Flowing water, door open and close, bow shooting, explosions, near a portal.
x SFX volume can now be put up to 200% of normal
x Added a 'Place Torch' key. Defaults to "V" (which kinda looks like 2 torches, doesn't it?).
  It will swap to your torches on your toolbar, place one, then swap back to the previous item automatically.
  It will use a Redstone Torch if you don't have any torches.
x Toggle brightness works correctly if your brightness was already all the way up when MC started.       
x Reorganized the options screen -- keybindings, options, and volume controls are now on their own screens.
x Fixed 'ALT' key sticking after alt-tabbing in an out of MC. This caused just 'C' to open the options screen instead of ALT-C.
x Fixed ALT+T also starting chat if T is your chat key.
x Added ALT+R to cycle through auto tool modes.
x Added ALT+S to enable/disable auto sword.
x Added ALT+B to enable/disable auto block.
x Look Behind will work in a degraded mode when the EntityRenderer class is not included due to a mod conflict.


NEW IN VERSION 4.1
==================
x AudioMod compatibility
x Added AutoTool
x Added AutoBlock
x Added Void Fog option
x Added Tap to Sprint

NEW IN VERSION 4.0
==================
x Minecraft 1.8.1 compat
x Added an options GUI so you can configure ControlPack without ever touching controlpack.txt manually.
  Access it via the usual Minecraft Options dialog, or hit ALT+C while in the game.
x Added a "Toggle Brightness" key. This lets you instantly switch from your usual brightness setting to full brightness.
  This allows you to easily turn up the brightness in caves and then switch back to the moody level Minecraft was
  meant to be seen in.
x By popular request, added a "Toggle Use Item" key. Use with caution :)
x You can now control the volume of Pistons
x You can now control the volume of the Splashing Effect
x You can now configure the keybinding for look behind. Could be a mouse button or key.
x You can control the camera in better 3rd person view with the mouse by holding down middle mouse button
x Fixed some bugs with Smart Furnace
x MC 1.8.1 is laggy when rapidly changing camera angles, making Look Behind very jerky,
  so I removed the turning animation which helps a little.

NEW IN VERSION 3.1
==================
x Now all features can be disabled through options in controlpack.txt
x Added the Less Rain feature
x Added the Rain Volume feature
x Fixed a few bugs


NEW IN VERSION 3.0
==================
x Compatibility with Minecraft 1.7.3
x The LookBehind via Keyboard feature (Forward+Back) can be disabled via controlpack.txt
x You can now ROTATE THE CAMERA in any direction in Front 3rd Person View! :)
x All the toggle features will work correctly if you press them while also doing that action.
  For example, you can now press AutoRun while running manually, and you will continue to
  auto run after releasing the forward key. As always, you can start running manually again
  and auto run is cancelled for you automatically.


NEW IN VERSION 2.3
==================
x Added Better 3rd Person View.
x Fixed a bug that was preventing keybindings from saving across sessions.
x Now compatible with Zombe mod pack.


NEW IN VERSION 2.2
==================
x Compatible with MCPatcher for HD textures.
x LookBehind now works if you hold down back and forward at the same time.
x The Minecraft window automatically restores to its previous state on launch.


NEW IN VERSION 2.1
==================
x Compat with Minecraft 1.6.6

NEW IN VERSION 2.0
===================
x Added the Look Behind ability.
x Added Smart Furnace drops.
x Fixed issues with Auto Mining.
x Dropped the non-modloader version, and reduced the number of Minecraft files
  required to be altered, increasing its compatibility with other mods.
x NOTE: IF YOU ARE UPGRADING FROM 1.0 or 1.1, you MUST read the installation section.

NEW IN VERSION 1.1
===================
x Added Auto Mine command
x Added Run Distance command
x Moving forward or back while auto running will stop auto running
x Jumping while auto jumping will stop auto jumping

