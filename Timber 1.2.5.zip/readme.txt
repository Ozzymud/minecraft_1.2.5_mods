Installation:
(This is written on the premise you know how to get to your minecraft.jar)

1. Backup your minecraft.jar.
2. Delete META-INF.
3. Install ModLoader.
4. Copy this download into /.minecraft/mods/
5. Start up minecraft and play.

Debugging:
Try the tool found here - http://www.minecraftforum.net/topic/533027-minecrafterror/