Read the ENTIRE OP here for information and instructions for installation 

http://www.minecraftforum.net/topic/940974-124sonic-ethers-unbelievable-shaders-glsl-shaders-dynamic-shadows-more/