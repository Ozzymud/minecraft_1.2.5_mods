package mffs;

import immibis.core.net.IPacket;
import mffs.packet.PacketGenericUpdate;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;
import net.minecraft.src.TileEntity;

public abstract class TileEntityMFFS extends TileEntity implements IInventory {
	public void handleButton(int id) {}
	public int[] getUpdate() {return null;}
	public void handleUpdate(int[] p) {}
	public int[] getBaseUpdate() {return null;}
	public void handleBaseUpdate(int[] p) {}
	
	public int updateCount;
	public int baseUpdateCount;
	
	@Override public int getSizeInventory() {return 0;}
	@Override public ItemStack getStackInSlot(int var1) {return null;}
	@Override public ItemStack decrStackSize(int var1, int var2) {return null;}
	@Override public ItemStack getStackInSlotOnClosing(int var1) {return null;}
	@Override public void setInventorySlotContents(int var1, ItemStack var2) {}
	@Override public String getInvName() {return "MFFS";}
	@Override public int getInventoryStackLimit() {return 64;}
	@Override public void openChest() {}
	@Override public void closeChest() {}

	@Override
	public boolean isUseableByPlayer(EntityPlayer var1) {
		return worldObj.getBlockTileEntity(xCoord, yCoord, zCoord) == this && var1.getDistanceSq(xCoord+0.5, yCoord+0.5, zCoord+0.5) <= 64;
	}
}
