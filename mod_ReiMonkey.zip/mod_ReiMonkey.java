package net.minecraft.src;

import java.lang.reflect.Field;
import net.minecraft.client.Minecraft;

public class mod_ReiMonkey extends BaseMod {
	
	private boolean needMonkeyPatch;

	public mod_ReiMonkey() {
		ModLoader.setInGameHook(this, true, false);
	}

	@Override
	public String getVersion() {
		return "1.2.5";
	}

	@Override
	public void load() {
		needMonkeyPatch = true;
	}

	@Override
	public void serverConnect(NetClientHandler netclienthandler) {
		needMonkeyPatch = true;
	}
	
	@Override
    public boolean onTickInGame(float tick, Minecraft mc) {
		if (!needMonkeyPatch)
			return true;
		needMonkeyPatch = false;

		Object rei = null;
		try {
			rei = Class.forName("reifnsk.minimap.ReiMinimap").getDeclaredField("instance").get(null);
		} catch (Exception e) {
			mc.ingameGUI.addChatMessage("[reimonkey] Rei's Minimap is not installed, aborting");
			return false;
		}
		setTrue(rei, "allowCavemap");
		setTrue(rei, "allowEntitiesRadar");
		setTrue(rei, "allowEntityPlayer");
		setTrue(rei, "allowEntityAnimal");
		setTrue(rei, "allowEntityMob");
		setTrue(rei, "allowEntitySquid");
		setTrue(rei, "allowEntityLiving");
		//mc.ingameGUI.addChatMessage("[reimonkey] success");
		return true;
    }

	private void setTrue(Object obj, String fieldName) {
		try {
	        Field field = obj.getClass().getDeclaredField(fieldName);
	        field.setAccessible(true);
	        field.set(obj, true);
		} catch (Exception e) {}
	}
}
