ccSensors build 016 for minecraft 1.2.5
ccSensors is a minecraft mod that can read the internal statuses and values from various objects within the minecraft world.

for the most updated info & download check out the forums posts:
http://www.minecraftforum.net/topic/1121555-125-cc133-ccsensors-adding-sensors-to-minecraft-now-with-smp/
http://www.computercraft.info/forums2/index.php?/topic/126-mc-125-cc-133-ccsensors-smpssp/


sections:
.INSTALLATION
.USAGE
.SENSORS
.BLOCKS
.ITEMS


INSTALLATION
------------
1.client installation

    -   extract ccSensors-client[xxx]-build[xxx]_extractMe.zip into the .minecraft folder
        the following files and folders will be created in the mods folder:
        .minecraft/mods/ccSensors
        .minecraft/mods/ccSensors-client-MCxxx-Bxxx.zip
    -   modify the config to configure block ids or any other settings:
        .minecraft/config/ccSensors.config

2.server installation

    - extract ccSensors-server[xxx]-build[xxx]_extractMe.zip into the server folder
      this will place the mod .zip file in the mods folder and create a ccSensors folder.
    - configuration file:   config/ccSensors.config
    
3. bukkit installation
    under construction.
    
    
USAGE
-----

basic usage to get started with sensors:

1. place a remote sensor near the object you want to probe (a reactor, engine, chest,etc..)
   NOTE: each sensorModule/Probe may have different range.( 1 up to the Max range defined in the config file) 
   Example: IC2 reactor sensor,Proximity sensor range:10, all others default range: 2

2. place the appropriate SensorModule card in the remote sensor.
   each sensorModule provides probes for different objects.
   Example: BC SensorModule provides probes for buildcraft machines, World Sensor provides generic area readings.
   for a complete list of sensors refer to the SENSORS section.  

3. place a Controller Peripheral next to a computercraft Computer

4. get a new channel assigned from the controller gui and encode blank transmitter card(s) to the same channel  

5. right click with the encoded transmitter card on the remote sensor to connect the remote sensor to the same channel

6. use the computer and run:/ccSensors/console to get the sensor readings 


SENSORS
-------


WorldSensor
--------------------------
Description: provides basic readings from the MC world.
Range: not applicable(no range limit)
Probes: "Sea Level","Light Level","Rain Strength","Raining?","Day/Night","isThunderStorm","SensorHeight"

Inventory Sensor
--------------------------
Description: 
Range: 2
Probes: "InventoryInfo","InventoryContent"

Buildcraft3 Sensor
--------------------------
Description: 
Range: 2
Readings:
Possible targets:


Industrialcraft2 Sensor
--------------------------
Description: 
Range: 2
Readings:
Possible targets:

Forestry Sensor
--------------------------


Equivalent Exchange Sensor
--------------------------


RedPower2 Sensor
--------------------------


Thaumcraft2
--------------------------


Proximity Sensor
--------------------------


BLOCKS
------

1. remote sensor
2. sensor controller




ITEMS
-----




