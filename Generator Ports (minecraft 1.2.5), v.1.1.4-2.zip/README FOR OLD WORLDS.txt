How to use this mod with older worlds:

1. READ README.txt!
2. MAKE A BACKUP OF THE WORLD!
3. Create a file called worldgen.txt in the save folder (where level.dat is).
4. Inside the file, type the appropriate code from the list below.
5. Make sure you wrote it correctly!
6. Save and play the game



-- Codes --

For beta 1.8.1 worlds, type:
  force B181

For beta 1.7.3 worlds, type:
  force B173

For alpha 1.1.2_01 worlds, type:
  force A112_01

For SNOWY alpha 1.1.2_01 worlds, type:
  force A112_01 snow

Import of indev maps is not supported.