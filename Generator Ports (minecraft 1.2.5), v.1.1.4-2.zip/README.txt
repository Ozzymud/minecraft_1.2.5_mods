This mod is released with no warranty of any kind!

Generator ports by DatWorldGen


SUPPORTED GENERATORS:

Beta 1.8.1
Beta 1.7.3
Alpha 1.1.2_01
Indev


DEPENDENCIES:

Required: None.

Optional: ModLoader.

ModLoader is needed to use the classic grass and leaf textures with
the alpha 1.1.2_01 and indev generators. The generators can be used without it,
but grass and leaves will not have the classic bright green color.


COMPATIBILITY:

Should be compatible with anything that doesn't replace fp.class, ms.class or vx.class.


INSTALLATION:

If an earlier version of this mod is installed, delete these folders from minecraft.jar:

gen173
genA112_01
genCore
genIndev

It is important you delete those folders before installing this version!


1. Create a backup of minecraft.jar
2. Copy contents into minecraft.jar
   It won't load properly if you put it in the mods folder added by ModLoader.
3. Delete META-INF!
4. If you intend to play with an old world, read "README FOR OLD WORLDS.txt".
   If not then select the generator by using the world type button.
5. Play the game.